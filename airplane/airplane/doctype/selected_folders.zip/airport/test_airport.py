# Copyright (c) 2024, pooja and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestAirport(FrappeTestCase):
	pass
